package com.vhanma.hanmacombocallerr3;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int BG = 0xFF050506;
    private static final int PANEL = 0xFF111114;
    private static final int PANEL2 = 0xFF19191E;
    private static final int PANEL3 = 0xFF23232A;
    private static final int RED = 0xFFFF3B30;
    private static final int DEEP_RED = 0xFF8E1717;
    private static final int GOLD = 0xFFFFC857;
    private static final int CYAN = 0xFF63E6FF;
    private static final int MUTED = 0xFFA8A8B3;
    private static final int GREEN = 0xFF52D273;
    private static final int ORANGE = 0xFFFF9F43;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> namedLibrary = new ArrayList<>();
    private final List<String> codedLibrary = new ArrayList<>();
    private final List<GhostFrame> ghostTape = new ArrayList<>();
    private final List<GhostFrame> ghostReplay = new ArrayList<>();

    private SharedPreferences prefs;
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean running;
    private boolean paused;
    private boolean immersive;
    private boolean ghostMode;
    private boolean whyVisible;
    private boolean awaitingReveal;
    private long sessionStartMs;
    private long sessionEndMs;
    private long lastDurationMs = 300_000L;
    private long baseGapMs = 2600L;
    private long reactionDelayMs = 1200L;
    private float speechRate = 0.92f;
    private String voiceMode = "Opponent + call";
    private String pendingFeedback = "RESET";
    private TacticalEngine engine;
    private TacticalEngine.Config config;
    private TacticalEngine.Result currentResult;
    private int ghostIndex;
    private int sessionCalls;
    private int landedCount;
    private int lateCount;
    private int blockedCount;
    private int missedCount;
    private int counteredCount;

    private TextView opponentView;
    private TextView cueView;
    private TextView stateView;
    private TextView coachView;
    private TextView whyView;
    private TextView shardView;
    private TextView clockView;
    private TextView phaseView;
    private TextView pressureView;
    private TextView predictionView;
    private TextView weaknessView;
    private TextView constraintView;
    private TextView expectationView;
    private TextView powerPlanView;
    private TextView returnFireView;
    private Button pauseButton;
    private Button whyButton;

    private static final class GhostFrame {
        final String opponent;
        final String cue;
        final String state;
        final String coach;
        final String why;
        final String shard;
        final String phase;
        final String prediction;
        final String weakness;
        final String constraint;
        final String expectation;
        final String powerPlan;
        final String returnFire;
        GhostFrame(String opponent, String cue, String state, String coach, String why, String shard,
                   String phase, String prediction, String weakness, String constraint,
                   String expectation, String powerPlan, String returnFire) {
            this.opponent = safe(opponent); this.cue = safe(cue); this.state = safe(state); this.coach = safe(coach);
            this.why = safe(why); this.shard = safe(shard); this.phase = safe(phase); this.prediction = safe(prediction);
            this.weakness = safe(weakness); this.constraint = safe(constraint);
            this.expectation = safe(expectation); this.powerPlan = safe(powerPlan); this.returnFire = safe(returnFire);
        }
        static String safe(String s) { return s == null ? "" : s; }
    }

    private final Runnable clock = new Runnable() {
        @Override public void run() {
            if (!running) return;
            long now = System.currentTimeMillis();
            if (sessionEndMs > 0 && now >= sessionEndMs) {
                stopSession("ROUND COMPLETE");
                return;
            }
            long value = sessionEndMs > 0 ? Math.max(0L, sessionEndMs - now) : Math.max(0L, now - sessionStartMs);
            if (clockView != null) clockView.setText(formatTime(value) + (sessionEndMs > 0 ? " LEFT" : " ELAPSED"));
            handler.postDelayed(this, 250L);
        }
    };

    private final Runnable nextFallback = () -> {
        if (!running || paused) return;
        if (ghostMode) callNextGhost(); else callNext(pendingFeedback);
        pendingFeedback = "AUTO";
    };

    private final Runnable revealRunnable = () -> {
        if (running && !paused && awaitingReveal && !ghostMode) revealCurrent();
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            prefs = getSharedPreferences("hanma_r4", MODE_PRIVATE);
            migrateR3PreferencesIfNeeded();
            try { getWindow().setStatusBarColor(BG); } catch (Throwable ignored) {}
            try { getWindow().setNavigationBarColor(BG); } catch (Throwable ignored) {}
            loadLibraries();
            showSetup();
            handler.postDelayed(this::initEngineSafe, 80L);
            handler.postDelayed(this::initVoiceSafe, 450L);
        } catch (Throwable bootError) {
            showRecoveryScreen("STARTUP", bootError);
        }
    }

    private void migrateR3PreferencesIfNeeded() {
        if (prefs.getBoolean("migrated", false)) return;
        try {
            SharedPreferences old = getSharedPreferences("hanma_r3", MODE_PRIVATE);
            SharedPreferences.Editor e = prefs.edit();
            String[] strings = {"mode","dnaA","dnaB","dnaC","opponent","persona","strategy","range","stance","gap","duration","custom","shards"};
            for (String k : strings) if (old.contains(k)) e.putString(k, old.getString(k, ""));
            String[] ints = {"weightA","weightB","weightC","difficulty","rate"};
            for (String k : ints) if (old.contains(k)) e.putInt(k, old.getInt(k, 0));
            String[] bools = {"autoDifficulty","adaptiveMemory","feints","kicks","clinch","takedowns","ground","coach","why"};
            for (String k : bools) if (old.contains(k)) e.putBoolean(k, old.getBoolean(k, true));
            e.putBoolean("migrated", true).apply();
        } catch (Throwable ignored) {
            prefs.edit().putBoolean("migrated", true).apply();
        }
    }

    private void initEngineSafe() {
        if (engine != null) return;
        try {
            engine = new TacticalEngine(namedLibrary, codedLibrary);
            engine.importShardState(prefs == null ? "" : prefs.getString("shards", ""));
            engine.importCombatState(prefs == null ? "" : prefs.getString("combat_state", ""));
        } catch (Throwable first) {
            try {
                if (prefs != null) prefs.edit().remove("shards").remove("custom").apply();
                engine = new TacticalEngine(namedLibrary, codedLibrary);
            } catch (Throwable fatal) {
                showRecoveryScreen("TACTICAL ENGINE", fatal);
            }
        }
    }

    private void initVoiceSafe() {
        if (tts != null) return;
        try { tts = new TextToSpeech(this, this); }
        catch (Throwable voiceError) {
            tts = null; ttsReady = false;
            Toast.makeText(this, "Voice unavailable. R6 will run visually.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean ensureEngine() {
        if (engine == null) initEngineSafe();
        return engine != null;
    }

    private void showRecoveryScreen(String stage, Throwable error) {
        running = false; paused = false; ghostMode = false;
        LinearLayout root = verticalRoot();
        TextView title = label("R6 RECOVERY MODE", 28, RED, true); title.setGravity(Gravity.CENTER); root.addView(title, lp(0, 12));
        TextView msg = label(stage + " failed safely.\n\n" + error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage()), 15, Color.WHITE, false);
        msg.setTextIsSelectable(true); root.addView(msg, lp(0, 18));
        Button retry = button("RETRY CLEAN BOOT", 0xFF146C35); root.addView(retry, lp(0, 8));
        Button clear = button("CLEAR R6 SETTINGS + RETRY", 0xFF7D4B08); root.addView(clear, lp(0, 8));
        retry.setOnClickListener(v -> recreate());
        clear.setOnClickListener(v -> { if (prefs != null) prefs.edit().clear().apply(); recreate(); });
        setContentView(root);
    }

    private void loadLibraries() {
        namedLibrary.clear(); codedLibrary.clear();
        readAsset("combos_named.txt", namedLibrary); readAsset("combos_codes.txt", codedLibrary);
    }

    private void readAsset(String filename, List<String> out) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open(filename)))) {
            String line; while ((line = reader.readLine()) != null) { String s = line.trim(); if (!s.isEmpty()) out.add(s); }
        } catch (Exception e) { Toast.makeText(this, "Missing library: " + filename, Toast.LENGTH_LONG).show(); }
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) return;
        ttsReady = true;
        try { tts.setLanguage(Locale.US); tts.setSpeechRate(speechRate); tts.setPitch(0.96f); } catch (Throwable ignored) {}
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}
            @Override public void onError(String utteranceId) { onDone(utteranceId); }
            @Override public void onDone(String utteranceId) {
                if (utteranceId == null) return;
                if (utteranceId.startsWith("r4-event-")) handler.postDelayed(revealRunnable, Math.max(0L, reactionDelayMs));
                else if (utteranceId.startsWith("r4-full-") || utteranceId.startsWith("r4-cue-") || utteranceId.startsWith("r4-ghost-"))
                    handler.post(MainActivity.this::scheduleNextAfterSpeech);
                else if (utteranceId.startsWith("r4-eventonly-")) handler.post(MainActivity.this::scheduleNextAfterSpeech);
            }
        });
    }

    private void showSetup() {
        stopInternal(); leaveImmersive(); ghostMode = false;
        ScrollView scroll = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(14), dp(20), dp(14), dp(38)); panel.setBackgroundColor(BG);
        scroll.addView(panel); setContentView(scroll);

        TextView title = label("HANMA COMBO CALLER R6", 31, Color.WHITE, true); title.setGravity(Gravity.CENTER); panel.addView(title, lp(0, 2));
        TextView sub = label("ADAPTIVE COMBAT INTELLIGENCE • OFFLINE", 13, RED, true); sub.setGravity(Gravity.CENTER); panel.addView(sub, lp(0, 3));
        TextView count = label((namedLibrary.size() + codedLibrary.size()) + " original slots + R6 causal threat-response graph + persistent rival memory", 13, MUTED, false);
        count.setGravity(Gravity.CENTER); panel.addView(count, lp(0, 16));

        Spinner mode = spinner(TacticalEngine.MODES);
        Spinner dnaA = spinner(TacticalEngine.PROFILES); Spinner dnaB = spinner(TacticalEngine.PROFILES); Spinner dnaC = spinner(TacticalEngine.PROFILES);
        Spinner opponent = spinner(TacticalEngine.OPPONENTS); Spinner persona = spinner(TacticalEngine.PERSONAS); Spinner strategy = spinner(TacticalEngine.STRATEGIES);
        Spinner range = spinner(TacticalEngine.RANGES); Spinner stance = spinner(TacticalEngine.STANCES);
        setSelection(mode, prefs.getString("mode", "Fight Simulator"));
        setSelection(dnaA, prefs.getString("dnaA", "Hanma Adaptive")); setSelection(dnaB, prefs.getString("dnaB", "Ilia Topuria")); setSelection(dnaC, prefs.getString("dnaC", "Prime Conor McGregor"));
        setSelection(opponent, prefs.getString("opponent", "Adaptive Rival")); setSelection(persona, prefs.getString("persona", "Balanced Hunt"));
        setSelection(strategy, prefs.getString("strategy", "Hanma Synthesis")); setSelection(range, prefs.getString("range", "Boxing")); setSelection(stance, prefs.getString("stance", "Auto-switch"));

        section(panel, "QUICK FIGHT PRESETS");
        LinearLayout p1 = horizontal(); Button hanma = button("HANMA MMA", DEEP_RED); Button topuria = button("TOPURIA", PANEL3); Button conor = button("MCGREGOR", PANEL3);
        p1.addView(hanma, weight()); p1.addView(topuria, weight()); p1.addView(conor, weight()); panel.addView(p1, lp(2, 4));
        LinearLayout p2 = horizontal(); Button sentinel = button("52 SENTINEL", PANEL3); Button gsp = button("GSP MIX", PANEL3); Button chaos = button("CHAOS", PANEL3);
        p2.addView(sentinel, weight()); p2.addView(gsp, weight()); p2.addView(chaos, weight()); panel.addView(p2, lp(0, 8));

        addField(panel, "MODE", mode);
        section(panel, "STYLE PRIORITY MIXER");
        addField(panel, "PRIMARY STYLE", dnaA); TextView weightALabel = label("PRIMARY PRIORITY", 12, MUTED, true); SeekBar weightA = seek(100, prefs.getInt("weightA", 60)); panel.addView(weightALabel, lp(2,0)); panel.addView(weightA, lp(0,3));
        addField(panel, "SECONDARY STYLE", dnaB); TextView weightBLabel = label("SECONDARY PRIORITY", 12, MUTED, true); SeekBar weightB = seek(100, prefs.getInt("weightB", 25)); panel.addView(weightBLabel, lp(2,0)); panel.addView(weightB, lp(0,3));
        addField(panel, "WILDCARD STYLE", dnaC); TextView weightCLabel = label("WILDCARD PRIORITY", 12, MUTED, true); SeekBar weightC = seek(100, prefs.getInt("weightC", 15)); panel.addView(weightCLabel, lp(2,0)); panel.addView(weightC, lp(0,7));
        Runnable updateWeights = () -> updateWeightLabels(weightALabel, weightBLabel, weightCLabel, weightA.getProgress(), weightB.getProgress(), weightC.getProgress());
        SimpleSeek wl = new SimpleSeek(){ @Override public void onProgressChanged(SeekBar seekBar,int progress,boolean fromUser){ updateWeights.run(); }};
        weightA.setOnSeekBarChangeListener(wl); weightB.setOnSeekBarChangeListener(wl); weightC.setOnSeekBarChangeListener(wl); updateWeights.run();

        section(panel, "OPPONENT + ROUND STATE");
        addField(panel, "OPPONENT BRAIN", opponent); addField(panel, "ROUND PERSONA", persona); addField(panel, "STRATEGY LAYER", strategy);
        addField(panel, "START RANGE", range); addField(panel, "STANCE", stance);

        TextView difficultyLabel = label("DIFFICULTY", 13, CYAN, true); SeekBar difficulty = seek(9, Math.max(0, prefs.getInt("difficulty", 5)-1)); TextView difficultyValue = label("",14,Color.WHITE,true);
        panel.addView(difficultyLabel, lp(8,2)); panel.addView(difficultyValue,lp(0,0)); panel.addView(difficulty,lp(0,5));
        difficulty.setOnSeekBarChangeListener(new SimpleSeek(){ @Override public void onProgressChanged(SeekBar seekBar,int progress,boolean fromUser){ difficultyValue.setText("LEVEL "+(progress+1)+" / 10"); }}); difficultyValue.setText("LEVEL "+(difficulty.getProgress()+1)+" / 10");

        section(panel, "DECISION TRAINING");
        Spinner gap = spinner(new String[]{"0.8 sec","1.2 sec","1.8 sec","2.6 sec","3.5 sec","5 sec","7 sec"});
        Spinner duration = spinner(new String[]{"1 minute","3 minutes","5 minutes","10 minutes","20 minutes","Endless"});
        Spinner reveal = spinner(new String[]{"Instant","0.7 sec","1.2 sec","1.8 sec","2.5 sec","4 sec"});
        Spinner voice = spinner(new String[]{"Opponent + call","Full tactical voice","Calls only","Opponent only"});
        setSelection(gap,prefs.getString("gap","2.6 sec")); setSelection(duration,prefs.getString("duration","5 minutes"));
        setSelection(reveal,prefs.getString("reveal","1.2 sec")); setSelection(voice,prefs.getString("voiceMode","Opponent + call"));
        addField(panel,"RECOVERY GAP AFTER CALL",gap); addField(panel,"ROUND LENGTH",duration); addField(panel,"BRANCHING SPAR REVEAL DELAY",reveal); addField(panel,"VOICE MODE",voice);
        TextView branchHint = label("Branching Spar hides the answer. Read the exact threat first, solve it yourself, then R6 reveals a prerequisite-locked defense and counter chain.",12,MUTED,false); panel.addView(branchHint,lp(0,6));

        TextView rateTitle = label("VOICE SPEED",13,CYAN,true); SeekBar rate=seek(100,prefs.getInt("rate",52)); TextView rateValue=label("",14,Color.WHITE,true);
        panel.addView(rateTitle,lp(6,2)); panel.addView(rateValue,lp(0,0)); panel.addView(rate,lp(0,6));
        rate.setOnSeekBarChangeListener(new SimpleSeek(){ @Override public void onProgressChanged(SeekBar seekBar,int progress,boolean fromUser){ speechRate=0.40f+progress*0.01f; rateValue.setText(Math.round(speechRate*100f)+"%"); if(ttsReady&&tts!=null)tts.setSpeechRate(speechRate); }});
        speechRate=0.40f+rate.getProgress()*0.01f; rateValue.setText(Math.round(speechRate*100f)+"%");

        section(panel,"R6 CAUSAL ENGINE SWITCHES");
        CheckBox autoDifficulty=check("Automatic difficulty evolution",prefs.getBoolean("autoDifficulty",true));
        CheckBox adaptiveMemory=check("Adaptive tactical memory",prefs.getBoolean("adaptiveMemory",true));
        CheckBox conditioning=check("Conditioning → exploitation round memory",prefs.getBoolean("conditioning",true));
        CheckBox weakness=check("Target weak categories from feedback",prefs.getBoolean("weakness",true));
        CheckBox strictFlow=check("Strict anti-stupid-combo flow filter",prefs.getBoolean("strictFlow",true));
        CheckBox rivalMemory=check("Persistent rival memory across rounds",prefs.getBoolean("rivalMemory",true));
        CheckBox powerIntent=check("Power-intent + kinetic position graph",prefs.getBoolean("powerIntent",true));
        CheckBox arenaIQ=check("Cage geometry + return-fire prediction",prefs.getBoolean("arenaIQ",true));
        CheckBox feints=check("Feints, draws and hand traps",prefs.getBoolean("feints",true));
        CheckBox kicks=check("Kicks and knees",prefs.getBoolean("kicks",true)); CheckBox clinch=check("Clinch and elbows",prefs.getBoolean("clinch",true));
        CheckBox takedowns=check("Takedowns and wrestling bridges",prefs.getBoolean("takedowns",true)); CheckBox ground=check("Ground continuations",prefs.getBoolean("ground",true));
        CheckBox coach=check("Coach interruptions",prefs.getBoolean("coach",true)); CheckBox why=check("Enable tactical WHY panel",prefs.getBoolean("why",true));
        CheckBox[] switches={autoDifficulty,adaptiveMemory,conditioning,weakness,strictFlow,rivalMemory,powerIntent,arenaIQ,feints,kicks,clinch,takedowns,ground,coach,why}; for(CheckBox b:switches)panel.addView(b);

        section(panel,"CUSTOM TECHNIQUE LAB");
        TextView syntax=label("One move per line: Name | START RANGE | ROLE | END RANGE | tags\nExample: Spear Jab | BOXING | ATTACK | BOXING | boxing,head,lead,custom",12,MUTED,false); panel.addView(syntax,lp(0,4));
        EditText custom=new EditText(this); custom.setTextColor(Color.WHITE); custom.setHintTextColor(0xFF6D6D78); custom.setHint("Add your own moves..."); custom.setTextSize(14); custom.setMinLines(4); custom.setGravity(Gravity.TOP); custom.setBackground(card(PANEL,10,0xFF2C2C33)); custom.setPadding(dp(12),dp(12),dp(12),dp(12)); custom.setText(prefs.getString("custom","")); panel.addView(custom,lp(0,10));

        LinearLayout utility=horizontal(); Button test=button("TEST VOICE",PANEL3); Button resetShards=button("RESET SHARDS",PANEL3); utility.addView(test,weight()); utility.addView(resetShards,weight()); panel.addView(utility,lp(4,3));
        Button resetRival=button("RESET RIVAL FIGHT MEMORY",PANEL3); panel.addView(resetRival,lp(0,6));
        Button start=button("ENTER R6",DEEP_RED); start.setTextSize(21); panel.addView(start,lp(6,0));

        hanma.setOnClickListener(v->{ setSelection(mode,"Fight Simulator"); setSelection(dnaA,"Hanma Adaptive");setSelection(dnaB,"Ilia Topuria");setSelection(dnaC,"Prime Conor McGregor");setSelection(opponent,"Adaptive Rival");setSelection(persona,"Balanced Hunt");setSelection(strategy,"Hanma Synthesis");weightA.setProgress(55);weightB.setProgress(25);weightC.setProgress(20); });
        topuria.setOnClickListener(v->{ setSelection(mode,"Pressure Hunt");setSelection(dnaA,"Ilia Topuria");setSelection(dnaB,"Petr Yan");setSelection(dnaC,"Georges St-Pierre");setSelection(opponent,"Counter Striker");setSelection(persona,"Pressure Round");setSelection(strategy,"Scientific MMA");weightA.setProgress(65);weightB.setProgress(20);weightC.setProgress(15); });
        conor.setOnClickListener(v->{ setSelection(mode,"Branching Spar");setSelection(dnaA,"Prime Conor McGregor");setSelection(dnaB,"Anderson Silva");setSelection(dnaC,"Lyoto Machida");setSelection(opponent,"Pressure Fighter");setSelection(persona,"Counter Round");setSelection(strategy,"Musashi Five Rings");weightA.setProgress(65);weightB.setProgress(20);weightC.setProgress(15); });
        sentinel.setOnClickListener(v->{ setSelection(mode,"Counter Drill");setSelection(dnaA,"52 Blocks Sentinel");setSelection(dnaB,"Petr Yan");setSelection(dnaC,"Jon Jones");setSelection(opponent,"Pressure Fighter");setSelection(persona,"Survival Round");setSelection(strategy,"52 Blocks Sentinel");weightA.setProgress(70);weightB.setProgress(15);weightC.setProgress(15); });
        gsp.setOnClickListener(v->{ setSelection(mode,"MMA Transition");setSelection(dnaA,"Georges St-Pierre");setSelection(dnaB,"Demetrious Johnson");setSelection(dnaC,"Ilia Topuria");setSelection(opponent,"Adaptive Rival");setSelection(persona,"Wrestling Threat Round");setSelection(strategy,"Scientific MMA");weightA.setProgress(55);weightB.setProgress(25);weightC.setProgress(20); });
        chaos.setOnClickListener(v->{ setSelection(mode,"Tactical Chain");setSelection(dnaA,"Hanma Adaptive");setSelection(dnaB,"Demetrious Johnson");setSelection(dnaC,"Anderson Silva");setSelection(opponent,"Chaos Rival");setSelection(persona,"Chaos Round");setSelection(strategy,"Chaos Adaptation");weightA.setProgress(45);weightB.setProgress(30);weightC.setProgress(25); });

        test.setOnClickListener(v->speakDirect("Opponent steps in behind the cross. Slip outside. Cross to body. Lead hook head. Pivot left."));
        resetShards.setOnClickListener(v->{ prefs.edit().remove("shards").apply(); if(ensureEngine())engine.importShardState(""); Toast.makeText(this,"Skill shards reset.",Toast.LENGTH_SHORT).show(); });
        resetRival.setOnClickListener(v->{ prefs.edit().remove("combat_state").apply(); if(ensureEngine())engine.importCombatState(""); Toast.makeText(this,"Rival fight memory reset.",Toast.LENGTH_SHORT).show(); });

        start.setOnClickListener(v->{
            if(!ensureEngine()){Toast.makeText(this,"Tactical engine recovery is active.",Toast.LENGTH_LONG).show();return;}
            try{
                config=new TacticalEngine.Config(); config.mode=selected(mode); config.dnaA=selected(dnaA);config.dnaB=selected(dnaB);config.dnaC=selected(dnaC);
                int[] normalized=normalizeWeights(weightA.getProgress(),weightB.getProgress(),weightC.getProgress()); config.weightA=normalized[0];config.weightB=normalized[1];config.weightC=normalized[2];
                config.opponent=selected(opponent);config.persona=selected(persona);config.strategy=selected(strategy);config.startRange=selected(range);config.stance=selected(stance);config.baseDifficulty=difficulty.getProgress()+1;
                config.autoDifficulty=autoDifficulty.isChecked();config.adaptiveMemory=adaptiveMemory.isChecked();config.conditioningMemory=conditioning.isChecked();config.weaknessTargeting=weakness.isChecked();config.strictFlow=strictFlow.isChecked();
                config.persistentRivalMemory=rivalMemory.isChecked();config.powerIntent=powerIntent.isChecked();config.arenaIQ=arenaIQ.isChecked();config.returnFireIQ=arenaIQ.isChecked();
                config.allowFeints=feints.isChecked();config.allowKicks=kicks.isChecked();config.allowClinch=clinch.isChecked();config.allowTakedowns=takedowns.isChecked();config.allowGround=ground.isChecked();config.coachInterruptions=coach.isChecked();config.explainWhy=why.isChecked();config.customTechniques=custom.getText().toString();
                baseGapMs=parseGap(selected(gap)); reactionDelayMs=parseGap(selected(reveal)); voiceMode=selected(voice); lastDurationMs=parseDuration(selected(duration));
                saveSetup(config,selected(gap),selected(duration),selected(reveal),voiceMode,rate.getProgress(),custom.getText().toString());
                if("Ghost Replay".equals(config.mode)){ startGhostSession(lastDurationMs); return; }
                engine.setConfig(config);engine.importShardState(prefs.getString("shards",""));engine.importCombatState(prefs.getString("combat_state","")); startSession(lastDurationMs);
            }catch(Throwable sessionError){showRecoveryScreen("SESSION START",sessionError);}
        });
    }

    private void startSession(long durationMs) {
        running=true;paused=false;ghostMode=false;whyVisible=false;awaitingReveal=false;pendingFeedback="RESET";
        sessionCalls=landedCount=lateCount=blockedCount=missedCount=counteredCount=0;ghostTape.clear();
        sessionStartMs=System.currentTimeMillis();sessionEndMs=durationMs>0?sessionStartMs+durationMs:0L;lastDurationMs=durationMs;
        enterImmersive();showCaller();handler.removeCallbacks(clock);handler.post(clock);handler.postDelayed(()->callNext("RESET"),350L);
    }

    private void startGhostSession(long durationMs) {
        ghostReplay.clear();ghostReplay.addAll(loadGhostTape());
        if(ghostReplay.isEmpty()){Toast.makeText(this,"No Ghost Round saved yet. Run a normal round first.",Toast.LENGTH_LONG).show();return;}
        running=true;paused=false;ghostMode=true;whyVisible=false;awaitingReveal=false;ghostIndex=0;sessionCalls=0;
        sessionStartMs=System.currentTimeMillis();sessionEndMs=durationMs>0?sessionStartMs+durationMs:0L;lastDurationMs=durationMs;
        enterImmersive();showCaller();handler.removeCallbacks(clock);handler.post(clock);handler.postDelayed(this::callNextGhost,300L);
    }

    private void showCaller() {
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);screen.setPadding(dp(12),dp(10),dp(12),dp(10));screen.setBackgroundColor(BG);setContentView(screen);
        LinearLayout top=horizontal();TextView title=label(ghostMode?"R6 GHOST ROUND":"R6 CAUSAL FIGHT INTELLIGENCE",14,RED,true);clockView=label("00:00",13,MUTED,true);clockView.setGravity(Gravity.END);top.addView(title,weight());top.addView(clockView,weight());screen.addView(top,lp(0,4));
        LinearLayout meta=horizontal();phaseView=badge("PHASE",RED);pressureView=badge("PRESSURE",ORANGE);meta.addView(phaseView,weight());meta.addView(pressureView,weight());screen.addView(meta,lp(0,5));
        opponentView=label("READING OPPONENT...",16,GOLD,true);opponentView.setGravity(Gravity.CENTER);opponentView.setBackground(card(PANEL2,12,0xFF33333A));opponentView.setPadding(dp(10),dp(10),dp(10),dp(10));screen.addView(opponentView,lp(0,6));
        constraintView=label("",12,ORANGE,true);constraintView.setGravity(Gravity.CENTER);screen.addView(constraintView,lp(0,2));
        cueView=label("GET READY",30,Color.WHITE,true);cueView.setGravity(Gravity.CENTER);cueView.setBackground(card(PANEL,14,0xFF2C2C33));cueView.setPadding(dp(12),dp(16),dp(12),dp(16));LinearLayout.LayoutParams cueLp=new LinearLayout.LayoutParams(-1,0,1f);cueLp.setMargins(0,0,0,dp(6));screen.addView(cueView,cueLp);
        stateView=label("",12,CYAN,true);stateView.setGravity(Gravity.CENTER);screen.addView(stateView,lp(0,2));
        expectationView=label("",10,CYAN,true);expectationView.setGravity(Gravity.CENTER);screen.addView(expectationView,lp(0,1));
        powerPlanView=label("",10,GREEN,true);powerPlanView.setGravity(Gravity.CENTER);screen.addView(powerPlanView,lp(0,1));
        returnFireView=label("",10,ORANGE,true);returnFireView.setGravity(Gravity.CENTER);screen.addView(returnFireView,lp(0,2));
        predictionView=label("",11,GOLD,false);predictionView.setGravity(Gravity.CENTER);screen.addView(predictionView,lp(0,2));
        weaknessView=label("",11,ORANGE,true);weaknessView.setGravity(Gravity.CENTER);screen.addView(weaknessView,lp(0,2));
        coachView=label("",16,RED,true);coachView.setGravity(Gravity.CENTER);screen.addView(coachView,lp(0,2));
        shardView=label("",11,GREEN,true);shardView.setGravity(Gravity.CENTER);screen.addView(shardView,lp(0,2));
        whyView=label("",11,MUTED,false);whyView.setGravity(Gravity.CENTER);whyView.setVisibility(View.GONE);screen.addView(whyView,lp(0,4));

        LinearLayout f1=horizontal();Button landed=button("CLEAN",0xFF146C35);Button late=button("LATE",0xFF456C35);f1.addView(landed,weight());f1.addView(late,weight());screen.addView(f1,lp(0,3));
        LinearLayout f2=horizontal();Button blocked=button("BLOCKED",0xFF7D4B08);Button missed=button("MISSED",0xFF4B4B55);Button countered=button("COUNTERED",0xFF8E1717);f2.addView(blocked,weight());f2.addView(missed,weight());f2.addView(countered,weight());screen.addView(f2,lp(0,4));
        LinearLayout controls=horizontal();Button repeat=button("REPEAT",PANEL3);pauseButton=button("PAUSE",PANEL3);Button next=button("NEXT",PANEL3);controls.addView(repeat,weight());controls.addView(pauseButton,weight());controls.addView(next,weight());screen.addView(controls,lp(0,3));
        LinearLayout extras=horizontal();whyButton=button("WHY",PANEL2);Button reset=button("RESET RANGE",PANEL2);extras.addView(whyButton,weight());extras.addView(reset,weight());screen.addView(extras,lp(0,3));
        Button stop=button("END ROUND",0xFF5F1515);screen.addView(stop,lp(0,0));

        landed.setOnClickListener(v->immediateFeedback("CLEAN"));late.setOnClickListener(v->immediateFeedback("LATE"));blocked.setOnClickListener(v->immediateFeedback("BLOCKED"));missed.setOnClickListener(v->immediateFeedback("MISSED"));countered.setOnClickListener(v->immediateFeedback("COUNTERED"));
        repeat.setOnClickListener(v->replayCurrent());pauseButton.setOnClickListener(v->togglePause());next.setOnClickListener(v->immediateFeedback("SKIP"));
        whyButton.setOnClickListener(v->toggleWhy());reset.setOnClickListener(v->immediateFeedback("RESET"));stop.setOnClickListener(v->stopSession("ROUND ENDED"));
    }

    private TextView badge(String text,int color){TextView v=label(text,11,color,true);v.setGravity(Gravity.CENTER);v.setBackground(card(PANEL2,10,0xFF2E2E35));v.setPadding(dp(6),dp(5),dp(6),dp(5));return v;}

    private void callNext(String feedback) {
        if(!running||paused||ghostMode)return;
        if(!ensureEngine()){showRecoveryScreen("CALL ENGINE",new IllegalStateException("Engine unavailable"));return;}
        handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);awaitingReveal=false;if(ttsReady&&tts!=null)tts.stop();
        try{currentResult=engine.next(feedback);}catch(Throwable e){showRecoveryScreen("TACTICAL CALL",e);return;}
        sessionCalls++;updateLiveViews(currentResult,true);prefs.edit().putString("shards",engine.exportShardState()).putString("combat_state",engine.exportCombatState()).apply();recordGhost(currentResult);
        if("Branching Spar".equals(config.mode)) beginBranchingReveal(); else { cueView.setText(currentResult.cue); speakCurrentFull(); }
    }

    private void updateLiveViews(TacticalEngine.Result r, boolean hideCueForBranch) {
        opponentView.setText(r.opponentEvent);stateView.setText(r.state);phaseView.setText("PHASE • "+r.planPhase);pressureView.setText("RIVAL PRESSURE • "+r.pressure+"%");
        expectationView.setText(r.expectation);powerPlanView.setText(r.powerPlan);returnFireView.setText(r.returnFire);
        predictionView.setText(r.predictedReaction);weaknessView.setText("WEAKNESS FOCUS • "+r.weakness);coachView.setText(r.coach);shardView.setText(r.shardStatus);
        constraintView.setText(r.constraint==null||r.constraint.isEmpty()?"":"CONSTRAINT • "+r.constraint);whyView.setText(config!=null&&config.explainWhy?r.why:"");
        if(!hideCueForBranch||config==null||!"Branching Spar".equals(config.mode))cueView.setText(r.cue);
    }

    private void beginBranchingReveal() {
        awaitingReveal=true;cueView.setText("SOLVE IT");cueView.setTextColor(CYAN);
        String event=currentResult.opponentEvent;
        if(ttsReady&&tts!=null){speakText(event,"r4-event-");}
        else handler.postDelayed(revealRunnable,Math.max(0L,reactionDelayMs));
    }

    private void revealCurrent() {
        if(!running||paused||currentResult==null)return;awaitingReveal=false;cueView.setTextColor(Color.WHITE);cueView.setText(currentResult.cue);
        if("Opponent only".equals(voiceMode)||!ttsReady||tts==null){scheduleNextAfterSpeech();return;}
        String text=(currentResult.coach!=null&&!currentResult.coach.isEmpty()&&"Full tactical voice".equals(voiceMode)?currentResult.coach+". ":"")+normalizeForSpeech(currentResult.cue);
        speakText(text,"r4-cue-");
    }

    private void speakCurrentFull() {
        if(currentResult==null)return;
        if(!ttsReady||tts==null){handler.postDelayed(nextFallback,Math.max(900L,baseGapMs));return;}
        String text;
        if("Calls only".equals(voiceMode)) text=normalizeForSpeech(currentResult.cue);
        else if("Opponent only".equals(voiceMode)){text=currentResult.opponentEvent;speakText(text,"r4-eventonly-");return;}
        else if("Full tactical voice".equals(voiceMode)){
            String coach=currentResult.coach==null?"":currentResult.coach;String power=currentResult.powerPlan==null?"":currentResult.powerPlan;String ret=currentResult.returnFire==null?"":currentResult.returnFire;
            text=(coach.isEmpty()?"":coach+". ")+currentResult.opponentEvent+". "+normalizeForSpeech(currentResult.cue)+(power.isEmpty()?"":". "+power)+(ret.isEmpty()?"":". "+ret);
        }else text=currentResult.opponentEvent+". "+normalizeForSpeech(currentResult.cue);
        speakText(text,"r4-full-");
    }

    private void callNextGhost() {
        if(!running||paused||!ghostMode)return;handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);if(ttsReady&&tts!=null)tts.stop();
        if(ghostIndex>=ghostReplay.size()){stopSession("GHOST ROUND COMPLETE");return;}
        GhostFrame f=ghostReplay.get(ghostIndex++);sessionCalls++;
        opponentView.setText(f.opponent);cueView.setTextColor(Color.WHITE);cueView.setText(f.cue);stateView.setText(f.state);coachView.setText(f.coach);shardView.setText(f.shard);phaseView.setText("PHASE • "+f.phase);pressureView.setText("GHOST • "+ghostIndex+"/"+ghostReplay.size());expectationView.setText(f.expectation);powerPlanView.setText(f.powerPlan);returnFireView.setText(f.returnFire);predictionView.setText(f.prediction);weaknessView.setText(f.weakness.isEmpty()?"":"WEAKNESS FOCUS • "+f.weakness);constraintView.setText(f.constraint.isEmpty()?"":"CONSTRAINT • "+f.constraint);whyView.setText(f.why);
        if(ttsReady&&tts!=null)speakText(f.opponent+". "+normalizeForSpeech(f.cue),"r4-ghost-"); else handler.postDelayed(nextFallback,Math.max(900L,baseGapMs));
    }

    private void scheduleNextAfterSpeech() {
        if(!running||paused)return;long gap=baseGapMs;if(currentResult!=null&&!ghostMode)gap=Math.min(gap,currentResult.suggestedGapMs);gap=Math.max(600L,gap);handler.removeCallbacks(nextFallback);pendingFeedback="AUTO";handler.postDelayed(nextFallback,gap);
    }

    private void immediateFeedback(String feedback) {
        if(!running)return;handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);awaitingReveal=false;if(ttsReady&&tts!=null)tts.stop();
        if(ghostMode){handler.postDelayed(this::callNextGhost,100L);return;}
        if("CLEAN".equals(feedback)||"LANDED".equals(feedback))landedCount++;else if("LATE".equals(feedback))lateCount++;else if("BLOCKED".equals(feedback))blockedCount++;else if("MISSED".equals(feedback))missedCount++;else if("COUNTERED".equals(feedback))counteredCount++;
        pendingFeedback=feedback;handler.postDelayed(()->callNext(feedback),120L);
    }

    private void replayCurrent() {
        handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);
        if(ghostMode){if(ghostIndex<=0||ghostIndex>ghostReplay.size())return;GhostFrame f=ghostReplay.get(ghostIndex-1);speakDirect(f.opponent+". "+normalizeForSpeech(f.cue));return;}
        if(currentResult==null)return;speakDirect(currentResult.opponentEvent+". "+normalizeForSpeech(currentResult.cue));
    }

    private void togglePause() {
        paused=!paused;pauseButton.setText(paused?"RESUME":"PAUSE");
        if(paused){handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);if(ttsReady&&tts!=null)tts.stop();stateView.setText("PAUSED");}
        else{stateView.setText("RESUMED");Runnable resume=ghostMode?this::callNextGhost:()->callNext("AUTO");handler.postDelayed(resume,300L);}
    }

    private void toggleWhy(){whyVisible=!whyVisible;if(whyView!=null)whyView.setVisibility(whyVisible?View.VISIBLE:View.GONE);if(whyButton!=null)whyButton.setText(whyVisible?"HIDE WHY":"WHY");}

    private void stopSession(String message) {
        boolean hadRound=sessionCalls>0;boolean wasGhost=ghostMode;stopInternal();leaveImmersive();if(!wasGhost&&!ghostTape.isEmpty())saveGhostTape(ghostTape);if(hadRound)showSummary(message,wasGhost);else showSetup();
    }

    private void showSummary(String message, boolean wasGhost) {
        LinearLayout root=verticalRoot();TextView title=label(message,26,RED,true);title.setGravity(Gravity.CENTER);root.addView(title,lp(0,8));
        TextView tag=label(wasGhost?"GHOST REPLAY COMPLETE":"R6 ROUND REPORT",13,CYAN,true);tag.setGravity(Gravity.CENTER);root.addView(tag,lp(0,16));
        String stats=wasGhost?"Replayed "+sessionCalls+" tactical frames.":"Calls "+sessionCalls+"\nCLEAN "+landedCount+"   LATE "+lateCount+"\nBLOCKED "+blockedCount+"   MISSED "+missedCount+"   COUNTERED "+counteredCount;
        TextView stat=label(stats,18,Color.WHITE,true);stat.setGravity(Gravity.CENTER);stat.setBackground(card(PANEL,12,0xFF303038));stat.setPadding(dp(12),dp(16),dp(12),dp(16));root.addView(stat,lp(0,12));
        if(!wasGhost&&engine!=null){
            TextView intel=label("END PHASE • "+engine.getPlanPhase()+"\nDIFFICULTY • "+engine.getDifficulty()+"/10\nARENA • "+engine.getArenaPosition()+"\nINITIATIVE • "+engine.getInitiative()+"\nWEAKNESS • "+engine.getWeaknessReport()+"\n"+engine.getExpectationReport()+"\n"+engine.getMasteryReport(),14,MUTED,false);intel.setGravity(Gravity.CENTER);root.addView(intel,lp(0,16));
        }
        Button again=button(wasGhost?"REPLAY GHOST AGAIN":"RUN SAME ROUND AGAIN",DEEP_RED);root.addView(again,lp(0,6));
        Button ghost=button("REPLAY EXACT GHOST ROUND",PANEL3);root.addView(ghost,lp(0,6));
        Button setup=button("RETURN TO SETUP",PANEL2);root.addView(setup,lp(0,0));setContentView(root);
        again.setOnClickListener(v->{if(wasGhost)startGhostSession(lastDurationMs);else{if(engine!=null&&config!=null){engine.setConfig(config);engine.importShardState(prefs.getString("shards",""));engine.importCombatState(prefs.getString("combat_state",""));startSession(lastDurationMs);}else showSetup();}});
        ghost.setOnClickListener(v->startGhostSession(lastDurationMs));setup.setOnClickListener(v->showSetup());
    }

    private void recordGhost(TacticalEngine.Result r) {
        if(r==null)return;ghostTape.add(new GhostFrame(r.opponentEvent,r.cue,r.state,r.coach,r.why,r.shardStatus,r.planPhase,r.predictedReaction,r.weakness,r.constraint,r.expectation,r.powerPlan,r.returnFire));while(ghostTape.size()>160)ghostTape.remove(0);
    }

    private void saveGhostTape(List<GhostFrame> tape) {
        StringBuilder b=new StringBuilder();
        for(GhostFrame f:tape){if(b.length()>0)b.append('\n');String[] vals={f.opponent,f.cue,f.state,f.coach,f.why,f.shard,f.phase,f.prediction,f.weakness,f.constraint,f.expectation,f.powerPlan,f.returnFire};for(int i=0;i<vals.length;i++){if(i>0)b.append('|');b.append(b64(vals[i]));}}
        prefs.edit().putString("ghostTape",b.toString()).apply();
    }

    private List<GhostFrame> loadGhostTape() {
        List<GhostFrame> out=new ArrayList<>();String raw=prefs.getString("ghostTape","");if(raw==null||raw.trim().isEmpty())return out;
        for(String line:raw.split("\\n")){String[] p=line.split("\\|",-1);if(p.length<10)continue;try{out.add(new GhostFrame(unb64(p[0]),unb64(p[1]),unb64(p[2]),unb64(p[3]),unb64(p[4]),unb64(p[5]),unb64(p[6]),unb64(p[7]),unb64(p[8]),unb64(p[9]),p.length>10?unb64(p[10]):"",p.length>11?unb64(p[11]):"",p.length>12?unb64(p[12]):""));}catch(Throwable ignored){}}
        return out;
    }

    private String b64(String s){return Base64.encodeToString((s==null?"":s).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}
    private String unb64(String s){return new String(Base64.decode(s,Base64.NO_WRAP),StandardCharsets.UTF_8);}

    private void speakText(String text,String prefix) {
        if(!ttsReady||tts==null||text==null||text.trim().isEmpty()){handler.postDelayed(nextFallback,Math.max(900L,baseGapMs));return;}
        try{tts.setSpeechRate(speechRate);int result=tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,prefix+System.nanoTime());if(result==TextToSpeech.ERROR)handler.postDelayed(nextFallback,Math.max(900L,baseGapMs));}catch(Throwable e){handler.postDelayed(nextFallback,Math.max(900L,baseGapMs));}
    }

    private void speakDirect(String text) {
        if(!ttsReady||tts==null){Toast.makeText(this,"Voice engine is still loading.",Toast.LENGTH_SHORT).show();return;}
        try{tts.setSpeechRate(speechRate);tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"manual-"+System.nanoTime());}catch(Throwable ignored){}
    }

    private String normalizeForSpeech(String raw) {
        if(raw==null)return"";String s=raw.replace("→",", ").replace('—',',').replace(';',',');
        if(s.matches(".*\\d.*")&&s.matches(".*[-/{}<>].*")){
            s=s.replace("pivote","pivot").replace("/L/"," left ").replace("/R/"," right ").replace("<R>"," right ").replace("{","").replace("}","").replace("ccw"," counter clockwise ").replace("-"," , ").replace("/"," ");
            Matcher matcher=Pattern.compile("(?i)(\\d+)?([a-z]+)").matcher(s);StringBuffer out=new StringBuffer();while(matcher.find()){String number=matcher.group(1)==null?"":matcher.group(1)+" ";String letters=matcher.group(2).toLowerCase(Locale.US);StringBuilder spoken=new StringBuilder(number);for(int i=0;i<letters.length();i++){char c=letters.charAt(i);if(c=='b')spoken.append("bee ");else if(c=='p')spoken.append("pee ");else if(c=='f')spoken.append("eff ");else if(c=='t')spoken.append("tee ");else if(c=='s')spoken.append("ess ");else if(c=='l')spoken.append("left ");else if(c=='r')spoken.append("right ");else spoken.append(c).append(' ');}matcher.appendReplacement(out,Matcher.quoteReplacement(spoken.toString().trim()));}matcher.appendTail(out);s=out.toString();
        }
        return s.replaceAll("\\s+,\\s+",", ").replaceAll("\\s+"," ").trim();
    }

    private void saveSetup(TacticalEngine.Config c,String gap,String duration,String reveal,String voice,int rate,String custom) {
        prefs.edit().putString("mode",c.mode).putString("dnaA",c.dnaA).putString("dnaB",c.dnaB).putString("dnaC",c.dnaC).putInt("weightA",c.weightA).putInt("weightB",c.weightB).putInt("weightC",c.weightC)
                .putString("opponent",c.opponent).putString("persona",c.persona).putString("strategy",c.strategy).putString("range",c.startRange).putString("stance",c.stance).putInt("difficulty",c.baseDifficulty)
                .putBoolean("autoDifficulty",c.autoDifficulty).putBoolean("adaptiveMemory",c.adaptiveMemory).putBoolean("conditioning",c.conditioningMemory).putBoolean("weakness",c.weaknessTargeting).putBoolean("strictFlow",c.strictFlow)
                .putBoolean("rivalMemory",c.persistentRivalMemory).putBoolean("powerIntent",c.powerIntent).putBoolean("arenaIQ",c.arenaIQ)
                .putBoolean("feints",c.allowFeints).putBoolean("kicks",c.allowKicks).putBoolean("clinch",c.allowClinch).putBoolean("takedowns",c.allowTakedowns).putBoolean("ground",c.allowGround).putBoolean("coach",c.coachInterruptions).putBoolean("why",c.explainWhy)
                .putString("gap",gap).putString("duration",duration).putString("reveal",reveal).putString("voiceMode",voice).putInt("rate",rate).putString("custom",custom).apply();
    }

    private void stopInternal() {
        running=false;paused=false;awaitingReveal=false;handler.removeCallbacks(clock);handler.removeCallbacks(nextFallback);handler.removeCallbacks(revealRunnable);if(ttsReady&&tts!=null)try{tts.stop();}catch(Throwable ignored){}try{getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}catch(Throwable ignored){}
    }

    @Override public void onBackPressed(){if(running||immersive)stopSession("ROUND ENDED");else super.onBackPressed();}
    @Override protected void onDestroy(){stopInternal();if(tts!=null){try{tts.stop();tts.shutdown();}catch(Throwable ignored){}}super.onDestroy();}

    private void enterImmersive(){immersive=true;try{getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}catch(Throwable ignored){}try{if(android.os.Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();if(c!=null){c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}}else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}catch(Throwable ignored){}
    }
    private void leaveImmersive(){immersive=false;try{if(android.os.Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();if(c!=null)c.show(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());}else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);}catch(Throwable ignored){}
    }

    private long parseGap(String text){if(text==null||text.toLowerCase(Locale.US).contains("instant"))return 0L;Matcher m=Pattern.compile("([0-9.]+)").matcher(text);if(!m.find())return 2600L;try{return(long)(Double.parseDouble(m.group(1))*1000.0);}catch(Exception e){return 2600L;}}
    private long parseDuration(String text){if(text.toLowerCase(Locale.US).contains("endless"))return 0L;Matcher m=Pattern.compile("(\\d+)").matcher(text);return m.find()?Long.parseLong(m.group(1))*60_000L:300_000L;}
    private String formatTime(long ms){long sec=ms/1000L;return String.format(Locale.US,"%02d:%02d",sec/60L,sec%60L);}

    private int[] normalizeWeights(int a,int b,int c){int total=a+b+c;if(total<=0)return new int[]{34,33,33};int na=Math.round(a*100f/total);int nb=Math.round(b*100f/total);int nc=Math.max(0,100-na-nb);return new int[]{na,nb,nc};}
    private void updateWeightLabels(TextView a,TextView b,TextView c,int av,int bv,int cv){int[] n=normalizeWeights(av,bv,cv);a.setText("PRIMARY PRIORITY  "+n[0]+"%");b.setText("SECONDARY PRIORITY  "+n[1]+"%");c.setText("WILDCARD PRIORITY  "+n[2]+"%");}

    private Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convertView,ViewGroup parent){View v=super.getView(position,convertView,parent);if(v instanceof TextView){TextView t=(TextView)v;t.setTextColor(Color.WHITE);t.setTextSize(15);t.setPadding(dp(8),dp(8),dp(8),dp(8));}return v;}@Override public View getDropDownView(int position,View convertView,ViewGroup parent){View v=super.getDropDownView(position,convertView,parent);if(v instanceof TextView){TextView t=(TextView)v;t.setTextColor(Color.WHITE);t.setBackgroundColor(PANEL3);t.setPadding(dp(10),dp(12),dp(10),dp(12));}return v;}};adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(adapter);s.setBackground(card(PANEL,9,0xFF303038));return s;}
    private void setSelection(Spinner spinner,String value){if(value==null||spinner.getAdapter()==null)return;for(int i=0;i<spinner.getAdapter().getCount();i++)if(value.equals(String.valueOf(spinner.getAdapter().getItem(i)))){spinner.setSelection(i);return;}}
    private String selected(Spinner s){return String.valueOf(s.getSelectedItem());}
    private SeekBar seek(int max,int progress){SeekBar s=new SeekBar(this);s.setMax(max);s.setProgress(Math.max(0,Math.min(max,progress)));return s;}
    private CheckBox check(String text,boolean checked){CheckBox b=new CheckBox(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setChecked(checked);b.setButtonTintList(android.content.res.ColorStateList.valueOf(RED));return b;}
    private void addField(LinearLayout panel,String title,View field){panel.addView(label(title,11,CYAN,true),lp(7,2));panel.addView(field,lp(0,3));}
    private void section(LinearLayout panel,String text){TextView v=label(text,14,RED,true);v.setPadding(0,dp(6),0,dp(2));panel.addView(v,lp(12,2));}
    private Button button(String text,int color){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT_BOLD);b.setAllCaps(false);b.setPadding(dp(5),dp(10),dp(5),dp(10));b.setBackground(card(color,10,0xFF323239));return b;}
    private TextView label(String text,float size,int color,boolean bold){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT_BOLD);return v;}
    private LinearLayout verticalRoot(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(18),dp(26),dp(18),dp(26));r.setBackgroundColor(BG);return r;}
    private LinearLayout horizontal(){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);return row;}
    private LinearLayout.LayoutParams weight(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);p.setMargins(dp(3),0,dp(3),0);return p;}
    private LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private GradientDrawable card(int color,int radius,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));if(stroke!=0)g.setStroke(dp(1),stroke);return g;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener{@Override public void onStartTrackingTouch(SeekBar seekBar){}@Override public void onStopTrackingTouch(SeekBar seekBar){}}
}
